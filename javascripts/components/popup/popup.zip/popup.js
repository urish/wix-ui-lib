/*var p = new Popup({
	content: '<h1>sdf</h1>',
	onclose: function(evt){
		console.log('H11111');
	}
});

p.open();
*/



function Popup(options){
	this.options = $.extend(Popup.deafults, options);
	this.markup();
	this.close();
	this.setContent(this.options.content);
	this.setFooter(this.options.footer);
	this.setTitle(this.options.title);
	this.setPosition();
	this.bindEvents();
}

Popup.deafults = {
    parent: 'body',
    modal:false,
    modalBackground:'rgba(0,0,0,0.5)',  
	title: 'Popup',
	content: '<p>No Content</p>',
	footer:  '<button class="btn close-popup">Close</button>',
	height: 'auto',
	width: 300,
	onclose: function(){}
};


Popup.prototype.markup = function(){
	this.popup = document.createElement('div');
  
    this.modal = document.createElement('div');
	
  
  
	this.header = document.createElement('header');
	this.headerTitle = document.createElement('span');
	this.closeBtn = document.createElement('div');
	
	this.content = document.createElement('div');
	
	this.footer = document.createElement('div');

    this.modal.className = 'popup-modal';
    
	this.closeBtn.className = 'popup-close-btn close-popup';
	this.popup.className = 'popup';
	this.header.className = 'popup-header';
    this.content.className = 'popup-content';

    this.footer.className = 'popup-footer';
  
  
	this.popup.appendChild(this.header);
	this.popup.appendChild(this.content);
	this.popup.appendChild(this.footer);
	
	this.header.appendChild(this.headerTitle);
	this.header.appendChild(this.closeBtn);
	
};

Popup.prototype.setPosition = function(){
	var $popup = $(this.popup);
	$popup.css({
        position:'absolute',
		width: this.options.width,
		height: this.options.height,
		left: '50%',
		top: '50%',
		marginLeft: 0 - this.options.width/2,
		marginTop: 0 - $popup.height()/2
	});
	
};

Popup.prototype.setContent = function(content){
	$(this.content).empty().append(content);
};

Popup.prototype.setFooter = function(footerContent){
	$(this.footer).empty().append(footerContent);
};
Popup.prototype.setTitle = function(title){
	$(this.headerTitle).text(title);
};

Popup.prototype.isOpen = function(title){
	return this.popup.style.display !== 'none';
};


Popup.prototype.open = function(){
    document.body.appendChild(this.modal);
    $(this.options.parent).append(this.popup);
  
	this.popup.style.display = 'block';
    this.modal.style.display = 'block';
    this.modal.style.backgroundColor = this.options.modalBackground;
    this.setPosition();
};

Popup.prototype.close = function(){
   this.modal.style.display = 'none';
   this.popup.style.display = 'none';
    
   $(this.modal).remove();
   $(this.popup).remove();
};

Popup.prototype.bindEvents = function(){
	var popup = this;
	$(this.popup).on('click', '.close-popup', function(){
		popup.close();
		popup.options.onclose.call(popup);
	});
};

















